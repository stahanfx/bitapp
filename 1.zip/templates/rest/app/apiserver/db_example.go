package apiserver

import (
	"net/http"
)

func (s *server) DBExample() http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		if TokenA(r) {
			str := r.FormValue("string")
			data, err := s.dbStore.DBExample().DBExample(str)
			ResponceData(data, err, w)
		} else {
			BadToken(w)
		}
	}
}
