package apistore

import "rest/store"

type ApiStore struct {
	apiExampleRepository *ApiExampleRepository
}

func New() *ApiStore {
	return &ApiStore{}
}

func (s *ApiStore) ApiExample() store.ApiExampleRepository {
	if s.apiExampleRepository != nil {
		return s.apiExampleRepository
	}
	s.apiExampleRepository = &ApiExampleRepository{
		store: s,
	}
	return s.apiExampleRepository
}
