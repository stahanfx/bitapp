package mw

type MsConfig struct {
}

func NewMwConfig() *MsConfig {
	return &MsConfig{}
}
