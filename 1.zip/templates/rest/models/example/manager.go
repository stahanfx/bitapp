package example

import (
	_ "encoding/json"
	_ "net/http"
)

type Example struct {
	ID int64 `json:"id" db:"id"` // ID - id Example
}
