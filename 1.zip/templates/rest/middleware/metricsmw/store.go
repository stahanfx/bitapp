package metricsmw

import (
	_ "github.com/go-sql-driver/mysql"
	"github.com/prometheus/client_golang/prometheus"
	"github.com/prometheus/client_golang/prometheus/promauto"
	mw "rest/middleware"
)

//Структура стора
type MsStore struct {
	opsProcessed      *prometheus.CounterVec
	metricsRepository *MetricsRepository
}

func New() *MsStore {
	opsProcessed := promauto.NewCounterVec(prometheus.CounterOpts{
		Name: "myapp_processed_ops_total",
		Help: "The total number of processed events",
	}, []string{"method", "path", "statuscode"})
	return &MsStore{
		opsProcessed: opsProcessed,
	}
}

func (s *MsStore) Metrics() mw.MetricsRepository {
	if s.metricsRepository != nil {
		return s.metricsRepository
	}
	s.metricsRepository = &MetricsRepository{
		mwStore: s,
	}
	return s.metricsRepository
}
