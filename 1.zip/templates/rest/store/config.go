package store

type Config struct {
}

func NewConfig() *Config {
	return &Config{}
}
