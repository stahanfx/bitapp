package version

var VERSION = "0.2"
var REVISION = "unknown"
