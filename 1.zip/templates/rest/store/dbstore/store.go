package dbstore

import (
	_ "github.com/go-sql-driver/mysql"
	"github.com/upper/db/v4"
	"rest/store"
)

type DbStore struct {
	db                  db.Session
	dbExampleRepository *DBExampleRepository
}

func New(db db.Session) *DbStore {
	return &DbStore{
		db: db,
	}
}

func (s *DbStore) DBExample() store.DBExampleRepository {
	if s.dbExampleRepository != nil {
		return s.dbExampleRepository
	}
	s.dbExampleRepository = &DBExampleRepository{
		store: s,
	}
	return s.dbExampleRepository
}
