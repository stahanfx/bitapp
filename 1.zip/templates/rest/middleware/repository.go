package mw

import (
	"bufio"
	"net"
	"net/http"
)

type MetricsRepository interface {
	NewMetrics(next http.Handler) http.Handler
	WriteHeader(statusCode int)
	Write(p []byte) (int, error)
	Hijack() (net.Conn, *bufio.ReadWriter, error)
	Flush()
}
