package apiserver

import (
	"encoding/json"
	"net/http"
	"os"
	"rest/models/response"
)

func TokenA(r *http.Request) bool {
	token := r.Header.Get("Token-A")
	path, exists := os.LookupEnv("TOKEN_A")
	if exists && token == path {
		return true
	} else {
		return false
	}
}

func BadToken(w http.ResponseWriter) {
	re := response.ReDataModel{}
	re.Status = "error2"
	re.Data = nil
	err := "token error"
	re.Error = &err

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(&re)
}
