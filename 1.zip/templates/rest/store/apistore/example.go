package apistore

type ApiExampleRepository struct {
	store *ApiStore
}

func (r *ApiExampleRepository) ApiExample(str string) (string, error) {
	return str, nil
}
