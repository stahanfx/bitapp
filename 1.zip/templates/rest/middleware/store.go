package mw

type MsStore interface {
	Metrics() MetricsRepository
}
