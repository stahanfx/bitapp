package dbstore

import _ "github.com/upper/db/v4"

type DBExampleRepository struct {
	store *DbStore
}

// DBExample
// @Summary     DBExample Тестовый метод.
// @Tags        Example
// @Description Тестовый метод.
// @Security    Token-A
// @Produce     json
// @Accept      json
// @Param       string query    string false "_"
// @Success     200    {object} response.ReDataModel{}
// @Failure     400    {object} response.ReDataModel{} "err_code：_ - _； err_code：_ - _"
// @Router      /db.example [get]
func (r *DBExampleRepository) DBExample(str string) (string, error) {
	return str, nil
}
