package apiserver

import (
	"encoding/json"
	"fmt"
	"net/http"
	"rest/models/response"
)

type responseWriter struct {
	http.ResponseWriter
	code int
}

func (w *responseWriter) WriteHeader(statusCode int) {
	w.code = statusCode
	w.ResponseWriter.WriteHeader(statusCode)
}

func ResponceData(data interface{}, err error, w http.ResponseWriter) {
	re := response.ReDataModel{}
	if err != nil {
		re.Status = "error"
		re.Data = nil
		er := fmt.Sprint(err)
		re.Error = &er
	} else {
		re.Status = "success"
		re.Data = &data
		re.Error = nil
	}

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(&re)
}
