package store

type ApiExampleRepository interface {
	ApiExample(str string) (string, error)
}

type DBExampleRepository interface {
	DBExample(str string) (string, error)
}
