package apiserver

type Config struct {
	BaseURL  string `toml:"base_url"`
	BindAddr string `toml:"bind_addr"`
	LogLevel string `toml:"log_level"`
	TokenA   string `toml:"token_a"`

	DataBase string `toml:"database_url"`
}

func NewConfig() *Config {
	return &Config{}
}
