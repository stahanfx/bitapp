package apiserver

import (
	"github.com/gorilla/mux"
	"github.com/gorilla/sessions"
	"github.com/sirupsen/logrus"
	"github.com/upper/db/v4"
	"github.com/upper/db/v4/adapter/mysql"
	mw "rest/middleware"
	"rest/middleware/metricsmw"
	"rest/store"
	"rest/store/apistore"
	"rest/store/dbstore"

	"net/http"
	"os"
)

//Конфигурации сервера
type server struct {
	router       *mux.Router
	logger       *logrus.Logger
	apiStore     store.ApiStore
	dbStore      store.DbStore
	sessionStore sessions.Store
	mw           mw.MsStore
	configUrl    *Config
}

func newServer(mwStore mw.MsStore, apiStore store.ApiStore, dbStore store.DbStore, sessionStore sessions.Store, configUrl *Config) *server {
	s := &server{
		router:       mux.NewRouter(),
		logger:       logrus.New(),
		apiStore:     apiStore,
		dbStore:      dbStore,
		sessionStore: sessionStore,
		mw:           mwStore,
		configUrl:    configUrl,
	}
	s.Router()
	return s
}

func newSessDb(dbURL string) (db.Session, error) {
	settings, _ := mysql.ParseURL(dbURL)
	sess, err := mysql.Open(settings)
	if err != nil {
		return nil, err
	}
	if err := sess.Ping(); err != nil {
		return nil, err
	}
	return sess, nil
}

//Запуск сервера
func Start(config *Config) error {

	//Переменные окружения
	os.Setenv("TOKEN_A", config.TokenA)

	//DBsess
	db, err := newSessDb(config.DataBase)
	if err != nil {
		return err
	}

	//MIDDLE
	mwStore := metricsmw.New()

	//SESSION
	sessionStore := sessions.NewCookieStore([]byte(config.TokenA))

	//APISTORE
	apiStore := apistore.New()

	//DBSTORE
	dbStore := dbstore.New(db)

	//CONFIG
	configUrl := config

	//START
	srv := newServer(mwStore, apiStore, dbStore, sessionStore, configUrl)

	return http.ListenAndServe(config.BindAddr, srv)

	//return http.ListenAndServeTLS(
	//	config.BindAddr,
	//	"/etc/ssl/certs/legchelife.ru.crt",
	//	"/etc/ssl/certs/legchelife.ru.key",
	//	srv)
}
