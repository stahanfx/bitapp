package apiserver

import (
	"context"
	"fmt"
	"net/http"

	"github.com/google/uuid"
	"github.com/gorilla/handlers"
	"github.com/prometheus/client_golang/prometheus/promhttp"
	httpSwagger "github.com/swaggo/http-swagger"
	_ "rest/docs"
)

type ctxKey int8

const (
	sessionName        = "stahanfx"
	ctxKeyUser  ctxKey = iota
	ctxKeyRequestID
)

func (s *server) ServeHTTP(w http.ResponseWriter, r *http.Request) {
	s.router.ServeHTTP(w, r)
}

func (s *server) Router() {

	//METRIC
	s.router.Handle("/metrics", promhttp.Handler())
	s.router.Use(s.mw.Metrics().NewMetrics)
	path := fmt.Sprint(NewConfig().BaseURL, "/swagger/doc.json")
	//SWAGGER
	s.router.PathPrefix("/swagger/").Handler(httpSwagger.Handler(
		httpSwagger.URL(path), //The url pointing to API definition
		httpSwagger.DeepLinking(true),
		httpSwagger.DocExpansion("none"),
		httpSwagger.DomID("#swagger-ui"),
	))

	//SERVICES
	s.router.Use(s.accessControlMiddleware)
	s.router.Use(s.setRequestID)
	s.router.Use(s.logRequest)
	s.router.Use(handlers.CORS(handlers.AllowedOrigins([]string{"*"})))
	s.router.Use(handlers.CORS(handlers.AllowedHeaders([]string{
		"Accept", "Accept-Language", "Content-Type", "Content-Language",
		"Origin", "Token-A", "X-Request-Id", "Referer", "User-Agent",
		"Connection", "Host", "Accept-Encoding", "Content-Length", "Date", "Transfer-Encoding", "content-type", "accept",
	})))
	s.router.Use(handlers.CORS(handlers.AllowedMethods([]string{
		http.MethodHead, http.MethodGet, http.MethodPost, http.MethodPut, http.MethodPatch, http.MethodDelete, http.MethodOptions,
	})))

	//DBExample
	s.router.Path("/db.example").Queries().Headers().HandlerFunc(s.DBExample()).Methods("GET")

}

func (s *server) accessControlMiddleware(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Access-Control-Allow-Origin", "*")
		w.Header().Set("Access-Control-Allow-Methods", "GET, POST, OPTIONS, PUT, DELETE")
		w.Header().Set("Access-Control-Allow-Headers", "Origin, Content-Type, X-Request-Id, Accept, Referer, Token-A")

		if r.Method == "OPTIONS" {
			return
		}

		next.ServeHTTP(w, r)
	})
}

func (s *server) setRequestID(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		id := uuid.New().String()
		w.Header().Set("X-Request-ID", id)
		if r.Method == "OPTIONS" {
			return
		}

		next.ServeHTTP(w, r.WithContext(context.WithValue(r.Context(), ctxKeyRequestID, id)))
	})
}
