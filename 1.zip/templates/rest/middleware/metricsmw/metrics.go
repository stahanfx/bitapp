package metricsmw

import (
	"bufio"
	"errors"
	"net"
	"net/http"
	"strconv"

	"github.com/prometheus/client_golang/prometheus"
)

type MetricsRepository struct {
	mwStore  *MsStore
	responce *ResponseWriterInterceptor
}

// Metrics middleware to collect metrics from http requests
func (lm *MetricsRepository) NewMetrics(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {

		wi := &ResponseWriterInterceptor{
			statusCode:     http.StatusOK,
			ResponseWriter: w,
		}
		next.ServeHTTP(wi, r)

		lm.mwStore.opsProcessed.With(prometheus.Labels{"method": r.Method, "path": r.RequestURI, "statuscode": strconv.Itoa(wi.statusCode)}).Inc()
	})
}

type ResponseWriterInterceptor struct {
	http.ResponseWriter
	statusCode int
}

func (w *MetricsRepository) WriteHeader(statusCode int) {
	w.responce.statusCode = statusCode
	w.responce.ResponseWriter.WriteHeader(statusCode)
}

func (w *MetricsRepository) Write(p []byte) (int, error) {
	return w.responce.ResponseWriter.Write(p)
}

func (w *MetricsRepository) Hijack() (net.Conn, *bufio.ReadWriter, error) {
	h, ok := w.responce.ResponseWriter.(http.Hijacker)
	if !ok {
		return nil, nil, errors.New("type assertion failed http.ResponseWriter not a http.Hijacker")
	}
	return h.Hijack()
}

func (w *MetricsRepository) Flush() {
	f, ok := w.responce.ResponseWriter.(http.Flusher)
	if !ok {
		return
	}

	f.Flush()
}
