package store

type ApiStore interface {
	ApiExample() ApiExampleRepository
}

type DbStore interface {
	DBExample() DBExampleRepository
}
